import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;

public class Main {
    public static final int NUMBER_OF_TESTS = 10;
    public static final int CYCLE_STEP = 1000;

    public static final int FROM = 1000;
    public static final int TO = 100000;

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        ChartPanel panel = new ChartPanel(createChart());
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setPreferredSize(new Dimension(1300, 900));
        frame.setContentPane(panel);
        frame.pack();
    }

    public static XYDataset createDataset() {
        XYSeriesCollection dataset = new XYSeriesCollection();
        XYSeries series = new XYSeries("");
        Random r = new Random();
        for (int i = FROM; i <= TO; i += CYCLE_STEP) {
            long result = 0;
            boolean isDense = true;
            for (int k = 0; k < NUMBER_OF_TESTS; k++) {
                int[] array = new int[i];
                for (int j = 0; j < array.length; j++)
                    array[j] = r.nextInt(0, 1000); // использовать более широкий диапазон значений

                long startTime = System.nanoTime();
                mostFrequencyNumber(array);
                long endTime = System.nanoTime();
                result += (endTime - startTime);

                isDense = isDense && isDenseArray(array);
            }
            series.add(i, result / NUMBER_OF_TESTS);

            // Выводим результаты для каждой итерации
            System.out.println("Размер массива: " + i + ", Время: " + result / NUMBER_OF_TESTS / 1e6 + " мс, Плотный: " + isDense);
        }
        dataset.addSeries(series);
        return dataset;
    }

    public static JFreeChart createChart() {
        return ChartFactory.createXYLineChart("График", "Кол-во элементов", "Время в мс", createDataset());
    }

    public static boolean isDenseArray(int[] array) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException("Array must not be null or empty.");
        }

        int min = array[0];
        int max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] < min) {
                min = array[i];
            }
            if (array[i] > max) {
                max = array[i];
            }
        }

        HashSet<Integer> uniqueValues = new HashSet<>();
        for (int value : array) {
            uniqueValues.add(value);
        }

        return uniqueValues.size() == (max - min + 1);
    }

    public static int mostFrequencyNumber(int[] array) {
        if (array == null) throw new NullPointerException();
        if (array.length == 0) throw new RuntimeException();
        Map<Integer, Integer> map = new HashMap<>();
        for (int key : array) {
            map.put(key, map.containsKey(key) ? map.get(key) + 1 : 1);
        }
        int mostFreq = array[0], freq = 0;
        for (Map.Entry<Integer, Integer> pair : map.entrySet()) {
            if (pair.getValue() > freq) {
                freq = pair.getValue();
                mostFreq = pair.getKey();
            }
        }
        return mostFreq;
    }
}
